mkfifo /tmp/pipe.out
mkfifo /tmp/pipe.in